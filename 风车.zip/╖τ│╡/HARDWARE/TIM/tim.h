#ifndef __TIM_H
#define __TIM_H	 
#include "sys.h"

void TIM_MODE_Init(void);
void TIM_NVIC_Init(void);
void TIM_Config(void);

		 				    
#endif
