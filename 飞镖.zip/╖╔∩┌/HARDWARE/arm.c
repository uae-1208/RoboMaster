#include "arm.h"
#include "pid.h"
#include "receive.h"

pid_position arm_position[2];
pid_increment arm_increment[2];
motor_angle arm_angle[2];



void arm_in_init(float kp,float ki,float kd,float max,float min)   //�ٶ��ڻ���ʼ��
{
	angle_init(&arm_angle[0]);
	angle_init(&arm_angle[1]);
	pid_position_init(&arm_position[0],kp,ki,kd,max,min);
	pid_position_init(&arm_position[1],kp,ki,kd,max,min);
}

void arm_out_init(float kp,float ki,float kd,float max,float min)  //�Ƕ��⻷��ʼ��
{
	pid_increment_init(&arm_increment[0],kp,ki,kd,max,min);
	pid_increment_init(&arm_increment[1],kp,ki,kd,max,min);
}


void arm_control()
{
	
}

