#ifndef __ARM_H__
#define __ARM_H__



void arm_in_init(float kp,float ki,float kd,float max,float min);
void arm_out_init(float kp,float ki,float kd,float max,float min);

#endif
