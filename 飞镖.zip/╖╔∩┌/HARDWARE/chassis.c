#include "chassis.h"
#include "receive.h"
#include "pid.h"

pid_position pid_position_3508[4];    //�����ĸ�3508��������λ��ʽ  


short wheel1,wheel2,wheel3,wheel4;  //�ĸ����ӵ�����ֵ
short set_current1,set_current2,set_current3,set_current4;  //pid����ķ���ֵ
short xspeed,yspeed,wspeed;	//x���ٶȣ�y���ٶȣ����ٶ�
short key_w,key_s,key_a,key_d,key_q,key_e;

float kx,ky,kw; //�ٶ�ϵ��

//------------------------------------------------------------------------------�˲������ϸ���

first_order_filter_type_t chassis_cmd_slow_set_vx;
first_order_filter_type_t chassis_cmd_slow_set_vy;
first_order_filter_type_t chassis_cmd_slow_set_vw;

void first_order_filter_init(first_order_filter_type_t *first_order_filter_type, float frame_period, const float num[1])
{
    first_order_filter_type->frame_period = frame_period;
    first_order_filter_type->num[0] = num[0];
    first_order_filter_type->input = 0.0f;
    first_order_filter_type->out = 0.0f;
}

void first_order_filter_cali(first_order_filter_type_t *first_order_filter_type, float input)
{
    first_order_filter_type->input = input;
    first_order_filter_type->out =
    first_order_filter_type->num[0] / (first_order_filter_type->num[0] + first_order_filter_type->frame_period) * first_order_filter_type->out + first_order_filter_type->frame_period / (first_order_filter_type->num[0] + first_order_filter_type->frame_period) * first_order_filter_type->input;
}


//--------------------------------------------------------------------------------------------

void chassis_init(float x,float y,float w,float kp,float ki,float kd,float max,float min) //���̳�ʼ������ȫ�����㣬��ֹ����
{
	wheel1=0,wheel2=0,wheel3=0,wheel4=0;
	set_current1=0,set_current2=0,set_current3=0,set_current4=0;
	xspeed=0,yspeed=0,wspeed=0;
	key_w=0,key_s=0,key_a=0,key_d=0,key_q=0,key_e=0;
	pid_position_init(&pid_position_3508[0],kp,ki,kd,max,min);
	pid_position_init(&pid_position_3508[1],kp,ki,kd,max,min);
	pid_position_init(&pid_position_3508[2],kp,ki,kd,max,min);
	pid_position_init(&pid_position_3508[3],kp,ki,kd,max,min);
	kx=x,ky=y,kw=w;
}



void handle_chassis_control(uint8_t key)    //�ֱ����Ƶ���
{

	xspeed=-RC_Ctl.rc.ch3;    //���ٶ����ֱ�����ֵ��Ӧ
	yspeed=-RC_Ctl.rc.ch2;
	wspeed=RC_Ctl.rc.ch0;
	
	first_order_filter_cali(&chassis_cmd_slow_set_vx, xspeed);//�˲�
  first_order_filter_cali(&chassis_cmd_slow_set_vy, yspeed);
  first_order_filter_cali(&chassis_cmd_slow_set_vw, wspeed);
	
	switch(key){  //�����ֱ����ϰ��ѡ���ٶ�
		case 2: kx=2,ky=2,kw=1;break;
		case 3:	kx=3,ky=3,kw=1.5;break;
		case 1:	kx=4,ky=4,kw=2;break;
	}
	

}

void keyboard_chassis_control()	//���̿��Ƶ���
{
	if(RC_Ctl.key.v & KEY_PRESSED_OFFSET_W)	key_w=2000;
	else key_w=0;
	if(RC_Ctl.key.v & KEY_PRESSED_OFFSET_S)	key_s=-2000;
	else key_s=0;
	if(RC_Ctl.key.v & KEY_PRESSED_OFFSET_A)	key_a=2000;
	else key_a=0;
	if(RC_Ctl.key.v & KEY_PRESSED_OFFSET_D)	key_d=-2000;
	else key_d=0;
	if(RC_Ctl.key.v & KEY_PRESSED_OFFSET_Q)	key_q=2000;
	else key_q=0;
	if(RC_Ctl.key.v & KEY_PRESSED_OFFSET_E)	key_e=-2000;
	else key_e=0;	
	
	xspeed=key_w+key_s;
	yspeed=key_a+key_d;
	wspeed=key_q+key_e;
	
	if(RC_Ctl.key.v & KEY_PRESSED_OFFSET_SHIFT){
		kx=1.5,ky=1.5;kw=1;
	}
		else if(RC_Ctl.key.v & KEY_PRESSED_OFFSET_CTRL){	kx=0.4,ky=0.4,kw=0.4;
	}
	
	else{  kx=1,ky=1,kw=0.7;
	}
}





/*

void chassis_control()
{
	handle_chassis_control(RC_Ctl.rc.s1);  //�ֱ����Ƶ���
	//keyboard_chassis_control();  //���̿��Ƶ���
	
		     //���̸������ٶ�
	wheel1=xspeed*kx+yspeed*ky-wspeed*kw;             //��ǰ
	wheel2=xspeed*kx-yspeed*ky-wspeed*kw;							//���
	wheel3=-(xspeed*kx-yspeed*ky+wspeed*kw);					//��ǰ
	wheel4=-(xspeed*kx+yspeed*ky+wspeed*kw);					//�Һ�

	set_current1=pid_position_calculate(&pid_position_3508[0],wheel1,receive_3508_chassis[0].Velocity_Value);
	set_current2=pid_position_calculate(&pid_position_3508[1],wheel2,receive_3508_chassis[1].Velocity_Value);
	set_current3=pid_position_calculate(&pid_position_3508[2],wheel3,receive_3508_chassis[2].Velocity_Value);
	set_current4=pid_position_calculate(&pid_position_3508[3],wheel4,receive_3508_chassis[3].Velocity_Value);
	
}
*/

