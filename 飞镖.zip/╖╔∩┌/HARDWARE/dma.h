#ifndef __DMA_H
#define __DMA_H
#include "sys.h"

void RC_Init(void);

#endif

