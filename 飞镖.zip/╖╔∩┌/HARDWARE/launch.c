#include "launch.h"
#include "receive.h"
#include "pid.h"
#include "can.h"
#include "led.h"


//�����ƶ�2006 ID1   �����ƶ�2006 ID2   ǣ��3508 ID4   ����2006 ID3

pid_position launch_x_out;
pid_position launch_x_in;
motor_angle launch_x_angle;

pid_position launch_y_out;
pid_position launch_y_in;
motor_angle launch_y_angle;

pid_position launch_offer_out;
pid_position launch_offer_in;
motor_angle launch_offer_angle;

pid_position launch_drag_out;
pid_position launch_drag_in;
motor_angle launch_drag_angle;

//int v_w,v_a,v_s,v_d,v_c,v_v,v_f,v_r;
int xspeed,yspeed,drag_speed,offer_speed;          
//short shoot;
short set_current1,set_current2,set_current3,set_current4;
//short servo1,servo2;




void launch_init()
{
//	v_w=0,v_a=0,v_s=0,v_d=0,v_c=0,v_v=0,v_f=0,v_r=0;
	
	xspeed=0,yspeed=0,drag_speed=0,offer_speed=0;
//	shoot=0;
	set_current1=0,set_current2=0,set_current3=0,set_current4=0;
//	servo1=0,servo2=0;
	pid_position_init(&launch_x_out,6,0.1,1,3000,-3000);
	pid_position_init(&launch_x_in,10,0.3,2,10000,-10000);
	angle_init(&launch_x_angle);

	pid_position_init(&launch_y_out,6,0.1,1,3000,-3000);
	pid_position_init(&launch_y_in,10,0.3,2,10000,-10000);
	angle_init(&launch_y_angle);
	
	pid_position_init(&launch_offer_out,6,0.1,1,3000,-3000);
	pid_position_init(&launch_offer_in,10,0.3,2,10000,-10000);
	angle_init(&launch_offer_angle);
	
	pid_position_init(&launch_drag_out,6,0.1,1,3000,-3000);
	pid_position_init(&launch_drag_in,12,2,2,10000,-10000);
	angle_init(&launch_drag_angle);
}



static void romate_control(void)
{
	//ǣ��
	if(RC_Ctl.rc.ch1 < -30)
		drag_speed = 500;
	else if(RC_Ctl.rc.ch1 > 30)
		drag_speed = -500;
	else
		drag_speed = 0;	

	
	
	//�ϵ�
	if(RC_Ctl.rc.ch3 < -30)
		offer_speed = 1000;
	else if(RC_Ctl.rc.ch3 > 30)
		offer_speed = -1000;
	else
		offer_speed = 0;
		
	
	//���	
	if(RC_Ctl.rc.s1 == 1 )
		TIM_SetCompare2(TIM2,115);
	else if(RC_Ctl.rc.s1 == 2)
		TIM_SetCompare2(TIM2,215);
	else
		TIM_SetCompare2(TIM2,140);
	
	
	//���	
	if(RC_Ctl.rc.s2 == 1 )
		TIM_SetCompare1(TIM2,160);
	else if(RC_Ctl.rc.s2 == 2)
		TIM_SetCompare1(TIM2,90);
	else
		TIM_SetCompare1(TIM2,110);


	
}




void launch_control()
{
	romate_control();
		
	set_current1=pid_position_calculate(&launch_x_in,xspeed,x_2006.Velocity_Value,300);
	set_current2=pid_position_calculate(&launch_y_in,yspeed,y_2006.Velocity_Value,300);
	set_current3=pid_position_calculate(&launch_offer_in,offer_speed,offer_2006.Velocity_Value,300);
	set_current4=pid_position_calculate(&launch_drag_in,drag_speed,drag_3508.Velocity_Value,300);
	
	CAN1_Send_Msg1(set_current1,set_current2,set_current3,set_current4);
}

