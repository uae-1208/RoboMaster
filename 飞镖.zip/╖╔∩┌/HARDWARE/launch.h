#ifndef __LAUNCH_H__
#define __LAUNCH_H__


void launch_control(void);
void launch_init(void);

#endif

