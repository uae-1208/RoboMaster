#ifndef __LED_H__
#define __LED_H__

#include "sys.h"
void Led_Init(void);


#define LED1 PGout(1) 
#define LED2 PGout(2) 
#define LED3 PGout(3) 
#define LED4 PGout(4) 
#define LED5 PGout(5) 
#define LED6 PGout(6) 
#define LED7 PGout(7) 
#define LED8 PGout(8) 


#endif
