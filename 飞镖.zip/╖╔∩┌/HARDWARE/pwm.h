#ifndef __PWM_H__
#define __PWM_H__

#include "sys.h"

void Pwm_Init_TIM2(u32 arr,u32 psc);
void Pwm_Init_TIM4(u32 arr,u32 psc);
void Pwm_Init_TIM5(u32 arr,u32 psc);
void Pwm_Init_TIM8(u32 arr,u32 psc);
void Servo_control(void);

#endif
