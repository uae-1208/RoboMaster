#include "receive.h"
#include "can.h"
#include "dma.h"


void RC_data_init()
{
	RC_Ctl.key.v=0;
	
	RC_Ctl.mouse.press_l=0;
	RC_Ctl.mouse.press_r=0;
	RC_Ctl.mouse.x=0;
	RC_Ctl.mouse.y=0;
	RC_Ctl.mouse.z=0;
	
	RC_Ctl.rc.ch0=0;
	RC_Ctl.rc.ch1=0;
	RC_Ctl.rc.ch2=0;
	RC_Ctl.rc.ch3=0;
	RC_Ctl.rc.s1=3;
	RC_Ctl.rc.s2=3;

}

void CAN1_RX0_IRQHandler( void )
{
	CanRxMsg rx_message;
	
	if ( CAN_GetITStatus(CAN1, CAN_IT_FMP0 ) != RESET )
	{
		CAN_ClearITPendingBit( CAN1, CAN_IT_FMP0 );
		CAN_Receive( CAN1, CAN_FIFO0, &rx_message );

		if ( (rx_message.IDE == CAN_Id_Standard) && (rx_message.IDE == CAN_RTR_Data) && (rx_message.DLC == 8) ) 
		{
			if ( rx_message.StdId == 0x201 )                                                              
			{
				x_2006.Temp_Value = rx_message.Data[6];
				x_2006.Torque_Value	= (rx_message.Data[4] << 8) | (rx_message.Data[5]);
				x_2006.Velocity_Value	= (rx_message.Data[2] << 8) | (rx_message.Data[3]);
				x_2006.Position_Value  = (rx_message.Data[0] << 8) | (rx_message.Data[1]);				
			}
			else if ( rx_message.StdId == 0x202 )                                                                
			{
				y_2006.Temp_Value = rx_message.Data[6];
				y_2006.Torque_Value	= (rx_message.Data[4] << 8) | (rx_message.Data[5]);
				y_2006.Velocity_Value	= (rx_message.Data[2] << 8) | (rx_message.Data[3]);
				y_2006.Position_Value  = (rx_message.Data[0] << 8) | (rx_message.Data[1]);
			}
			else if ( rx_message.StdId == 0x203 )                                                                
			{
				offer_2006.Temp_Value = rx_message.Data[6];
				offer_2006.Torque_Value	= (rx_message.Data[4] << 8) | (rx_message.Data[5]);
				offer_2006.Velocity_Value	= (rx_message.Data[2] << 8) | (rx_message.Data[3]);
				offer_2006.Position_Value  = (rx_message.Data[0] << 8) | (rx_message.Data[1]);
			}
			else if ( rx_message.StdId == 0x204 )                                                                
			{
				drag_3508.Temp_Value = rx_message.Data[6];
				drag_3508.Torque_Value	= (rx_message.Data[4] << 8) | (rx_message.Data[5]);
				drag_3508.Velocity_Value	= (rx_message.Data[2] << 8) | (rx_message.Data[3]);
				drag_3508.Position_Value  = (rx_message.Data[0] << 8) | (rx_message.Data[1]);
			}
		}
	}
}




motor_DJI_receive x_2006; 
motor_DJI_receive y_2006;
motor_DJI_receive offer_2006;
motor_DJI_receive drag_3508;

RC_Ctl_t RC_Ctl;
