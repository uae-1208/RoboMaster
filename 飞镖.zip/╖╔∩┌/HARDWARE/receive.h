#ifndef __RECEIVE_H
#define __RECEIVE_H	 

#include <stm32f4xx.h>

/* ----------------------- ���Լ��̶���-------------------------------- */
#define KEY_PRESSED_OFFSET_W ((uint16_t)1 << 0)
#define KEY_PRESSED_OFFSET_S ((uint16_t)1 << 1)
#define KEY_PRESSED_OFFSET_A ((uint16_t)1 << 2)
#define KEY_PRESSED_OFFSET_D ((uint16_t)1 << 3)
#define KEY_PRESSED_OFFSET_SHIFT ((uint16_t)1 << 4)
#define KEY_PRESSED_OFFSET_CTRL ((uint16_t)1 << 5)
#define KEY_PRESSED_OFFSET_Q ((uint16_t)1 << 6)
#define KEY_PRESSED_OFFSET_E ((uint16_t)1 << 7)
#define KEY_PRESSED_OFFSET_R ((uint16_t)1 << 8)
#define KEY_PRESSED_OFFSET_F ((uint16_t)1 << 9)
#define KEY_PRESSED_OFFSET_G ((uint16_t)1 << 10)
#define KEY_PRESSED_OFFSET_Z ((uint16_t)1 << 11)
#define KEY_PRESSED_OFFSET_X ((uint16_t)1 << 12)
#define KEY_PRESSED_OFFSET_C ((uint16_t)1 << 13)
#define KEY_PRESSED_OFFSET_V ((uint16_t)1 << 14)
#define KEY_PRESSED_OFFSET_B ((uint16_t)1 << 15)
//--------------------------------------------------------------------


typedef struct 
{
	unsigned char Temp_Value;  //�¶�
	short Torque_Value;	//Ť�ص�·
	short Velocity_Value;	//ת��
	short Position_Value; //�Ƕ�
}motor_DJI_receive;



typedef struct
{
		struct
		{
				short ch0;
				short ch1;
				short ch2;
				short ch3;
				uint8_t s1;
				uint8_t s2;
		}rc;
		
		struct
		{
				int16_t x;
				int16_t y;
				int16_t z;
				uint8_t press_l;
				uint8_t press_r;
		}mouse;
		
		struct
		{
				uint16_t v;
		}key;
}RC_Ctl_t;


typedef struct
{
	short counter1;//������
	short shoot;
}system_control;

extern system_control system_ctl;

extern motor_DJI_receive x_2006; 
extern motor_DJI_receive y_2006;
extern motor_DJI_receive offer_2006;
extern motor_DJI_receive drag_3508;

void RC_data_init(void);

extern RC_Ctl_t RC_Ctl;


#endif


