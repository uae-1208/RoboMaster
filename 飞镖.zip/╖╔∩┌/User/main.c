#include "main.h"
#include "delay.h"
#include "led.h"
#include "pid.h"
#include "receive.h"
#include "timer.h"
#include "pwm.h"
#include "launch.h"
#include "dma.h"
#include "can.h"

int main( void )
{
	delay_init( 180 );      /* ��ʱ������ʼ�� */
	delay_ms( 100 );
	
	CAN1_Mode_Init(CAN_SJW_1tq,CAN_BS2_7tq,CAN_BS1_7tq,3,CAN_Mode_Normal); //CANͨ�ų�ʼ��
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	RC_Init(); //dma��ʼ��������ң����
	delay_ms(10);
	RC_data_init();
	Led_Init();
	
	Pwm_Init_TIM2(2000-1,840-1);//  
	launch_init();
	
	LED1=0;
	LED2=1;
	
	while ( 1 )
	{	
		launch_control();
		delay_ms(3);
	}
}

